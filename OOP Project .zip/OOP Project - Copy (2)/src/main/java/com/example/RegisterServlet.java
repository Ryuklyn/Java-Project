
package com.example;

import com.example.oop_project.DBConnection.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet(name = "RegisterServlet", value = "/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection con = DBConnection.getConnection();

        String uname = request.getParameter("userName");
        String pwrd = request.getParameter("password");

        try {
            PreparedStatement ps = con.prepareStatement("INSERT INTO registered_users (username, password) VALUES (?, ?)");
            ps.setString(1, uname);
            ps.setString(2, pwrd);
            int rows = ps.executeUpdate();
            if (rows != 0) {
                System.out.println("User Added successfully");

                // Close the database connection
                con.close();

                // Redirect to login.jsp after successful registration
                RequestDispatcher dispatcher = request.getRequestDispatcher("pages/login.jsp");
                dispatcher.forward(request, response);
            } else {
                System.out.println("error");
                RequestDispatcher dispatcher = request.getRequestDispatcher("pages/register.jsp");
                dispatcher.forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
