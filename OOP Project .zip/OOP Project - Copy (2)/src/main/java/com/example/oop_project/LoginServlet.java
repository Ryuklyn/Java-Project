package com.example.oop_project;

import com.example.oop_project.DBConnection.DBConnection;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;


@WebServlet(name = "LoginServlet", value = "/LoginServlet")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try{
            PrintWriter out = response .getWriter();
            Connection con = DBConnection.getConnection();
            String name =request.getParameter("userName");
            String password =request.getParameter("password");

            if(con!=null){
                PreparedStatement ps = con.prepareStatement("select username from registered_users where username=? and password=?");
                ps.setString(1,name);
                ps.setString(2,password);
                ResultSet rs = ps.executeQuery();
                if(rs.next()){
                    RequestDispatcher rd = request.getRequestDispatcher("pages/dashboard.jsp");
                    rd.forward(request,response);
                }else{
                    out.println("<h1>Login Failed</h1>");
                    out.println("<a href='index.jsp'>Try Again</a>");
                }
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}