package com.example.oop_project.model;

import java.util.Date;

public class Income {
    private int id;
    private String source;
    private double amount;
    private Date date;

    public Income(int id, String source, double amount, Date date) {
        this.id = id;
        this.source = source;
        this.amount = amount;
        this.date = date;
    }

    public Income() {
        //Default Constructor
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
